say "Hello"

#CWD=$(pwd)
#echo $1 $2
#DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
cd $1

#phantom $1/render.js "$2" "$3"
#echo `pwd` > /Users/pt/output.txt


#phantom render.js "$1" "$2"

#cd "$CWD"

